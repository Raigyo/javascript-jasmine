[![Build Status](https://img.shields.io/travis/karma-runner/karma/master.svg?style=flat-square)]
